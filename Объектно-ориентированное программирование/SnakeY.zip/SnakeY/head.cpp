#include "head.h"

//Обнуляем ссылку на экземляр класса во избежание ошибок
Head* Head::my_instance = 0;

//Установить положение головы на указанные координаты x и y
//Принимает значения int
//Не возвращает значений
void Head::setHead(int newx, int newy)
{
    setX(newx);
    setY(newy);
}
//Сместить положение головы на указанные значения
//Принимает значения int
//Не возвращает значений
void Head::moveHead(int offsetx, int offsety)
{
    setX(getX()-offsetx);
    setY(getY()-offsety);
}
