#pragma once
#include <QWidget>
#include <QKeyEvent>
#include "head.h"
#include "apple.h"
#include "point.h"
#include "inputmanager.h"
#include "gameoverscreen.h"
#include "gamemanager.h"

//Класс отрисовки и контроля игры.
class DrawerManager : public QWidget, public Singleton {
public:
    //Конструктор
    DrawerManager(QWidget *parent = 0);


private:
    //Максимальное количество точек, доступных игроку
    static const int ALL_DOTS = 900;
    //Изображение точки (тела змеи)
    QImage dot;
    //Изображение головы змеи
    QImage head;
    //Изображение яблока
    QImage apple;

    //ID таймера
    int timerId;
    //Количество очков (точек тела змеи) у игрока
    int dots;

    //Массив точек тела змеи
    Point points[ALL_DOTS];
    //Идет ли еще игра?
    bool inGame;

    //Событие отрисовки
    void paintEvent(QPaintEvent *);
    //Событие таймера
    void timerEvent(QTimerEvent *);
    //Событие нажатия кнопки
    void keyPressEvent(QKeyEvent *);
    //Функция загрузки изображений из ресурсов
    void loadImages();
    //Функция старта игры
    void initGame();
    //Функция перемещения яблока
    void locateApple();
    //Функция проверки столкновения змейки с яблоком
    void checkApple();
    //Функция проверки столкновения змейки со стеной или собой
    void checkCollision();
    //Функция перемещения змейки
    void move();
    //Функция отрисовки змейки и яблока
    void doDrawing();
};
