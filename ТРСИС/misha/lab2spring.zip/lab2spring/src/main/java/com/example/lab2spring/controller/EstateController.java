package com.example.lab2spring.controller;

import com.example.lab2spring.entity.Estate;
import com.example.lab2spring.entity.User;
import com.example.lab2spring.exception.ElectronicAlreadyExistException;
import com.example.lab2spring.exception.ElectronicAreEmptyException;
import com.example.lab2spring.exception.ElectronicNotFoundException;
import com.example.lab2spring.service.EstateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/estates")
public class EstateController {

    @Autowired
    private EstateService estateService;

    @PostMapping
    public ResponseEntity<?> addElectronic(@RequestBody Estate estate) {
        try {
            estateService.addEstate(estate);
            return new ResponseEntity<>(estate, HttpStatus.CREATED);
        } catch (ElectronicAlreadyExistException error) {
            return ResponseEntity.badRequest().body(error.getMessage());
        } catch (ElectronicAreEmptyException e) {
            return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }catch (Exception error) {
            return ResponseEntity.badRequest().body("Произошла ошибка!");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getEstate(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(estateService.getEstate(id));
        } catch (ElectronicNotFoundException error) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error.getMessage());
        }
        catch (Exception error) {
            return ResponseEntity.badRequest().body("Произошла ошибка!");
        }
    }

    @GetMapping
    public ResponseEntity<?> getEstates() {
        try {
            return ResponseEntity.ok(estateService.getEstates());
        }
        catch (Exception error) {
            return ResponseEntity.badRequest().body("Произошла ошибка!");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEstate(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(estateService.deleteEstate(id));
        }
        catch (Exception error) {
            return ResponseEntity.badRequest().body("Произошла ошибка!");
        }
    }


    @GetMapping("/profile")
    public ResponseEntity<?> main(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(user);
    }


}