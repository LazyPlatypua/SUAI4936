package com.example.lab2spring.exception;

public class ElectronicNotFoundException extends Exception {
    public ElectronicNotFoundException(String message) {
        super(message);
    }
}
