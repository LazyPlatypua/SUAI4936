#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H
#include "QString"
#include "singleton.h"

//Класс игрового менеджера. Отвечает за хранение изменяемых дизайнером значений
class GameManager : public Singleton
{
public:
    //Стандартный пустой конструктор
    GameManager(){}

    //Функция получения ширины окна
    static int getB_WIDTH();
    //Функция получения высоты окна
    static int getB_HEIGHT();
    //Функция получения размера точек
    static int getDOT_SIZE();
    //Функция получения ограничения случайной генерации
    static int getRAND_POS();
    //Функция получения задержки между кадрами
    static int getDELAY();
    //Функция получения начального количества точек у змейки
    static int getSTART_DOTS();
    //Функция получения пути до изображения точки (тела змеи)
    //Функция получения начального расположения змейки
    static int getSTART_POS();
    static const char *getDOT_PATH();
    //Функция получения пути до изображения головы
    static const char *getHEAD_PATH();
    //Функция получения пути до изображения яблока
    static const char *getAPPLE_PATH();
    //Функция получения цвета фона
    static const char *getBACKGROUND_COLOUR();

private:
    //Ширина окна
    static const int B_WIDTH = 300;
    //Высота окна
    static const int B_HEIGHT = 300;
    //Размер точки
    static const int DOT_SIZE = 10;
    //Ограничение для случайной генерации
    static const int RAND_POS = 29;
    //Задержка между кадрами. Отвечает за скорость игры
    static const int DELAY = 140;
    //Начальное количество точек у змейки
    static const int START_DOTS = 3;
    //Начальное расположение змейки
    static const int START_POS = 150;
    //Путь до изображения точки
    static constexpr const char* DOT_PATH = ":snake/images/dot.png";
    //Путь до изображения головы
    static constexpr const char* HEAD_PATH = ":snake/images/head.png";
    //Путь до изображения яблока
    static constexpr const char* APPLE_PATH = ":snake/images/apple.png";
    //Цвет фона
    static constexpr const char* BACKGROUND_COLOUR = "background-color:black;";
};

#endif // GAMEMANAGER_H
