#ifndef POINT_H
#define POINT_H

#include "coords.h"


//Класс точки (тела змеи). Отвечает за расположение точки на экране
class Point : public Coords
{
public:
    //Стандартный пустой конструктор
    Point(){}
    //Установить положение точки по указанным координатам
    void setPos(int,int);
};

#endif // POINT_H
