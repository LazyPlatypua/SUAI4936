#ifndef COORDS_H
#define COORDS_H

//Класс координат. Содержит координаты x и y относительно окна программы, методы их установки и получения
class Coords
{
public:
    //Станадартный пустой конструктор
    Coords(){}

    //Метод получения координаты x
    int getX() const;
    //Метод установки координаты x
    void setX(int value);

    //Метод получения координаты y
    int getY() const;
    //Метод установки координаты y
    void setY(int value);

protected:
    //Координата x
    int x;
    //Координата y
    int y;
};

#endif // COORDS_H
