#include "point.h"

//Установить положение точки по указанным координатам
//Принимает значения int
//Не возвращает значений
void Point::setPos(int newx, int newy)
{
    setX(newx);
    setY(newy);
}
