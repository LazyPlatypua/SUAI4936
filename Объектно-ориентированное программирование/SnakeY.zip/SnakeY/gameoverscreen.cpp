#include "gameoverscreen.h"

//Обнуляем ссылку на экземляр класса во избежание ошибок
GameOverScreen* GameOverScreen::my_instance = 0;

//Функция отрисовки экрана конца игры
//Получает адрес Qpainter и значения int
//Не возвращает значений
void GameOverScreen::gameOver(QPainter &qp, int height, int width, int points)
{
    //Создать сообщение
    QString message = "Your score: " + QString::number(points);
    //Создать шрифт
    QFont font("Courier", 15, QFont::DemiBold);
    //Создать метрики измерения шрифта
    QFontMetrics fm(font);
    //Узнать ширину сообщения
    int textWidth = fm.horizontalAdvance(message);

    //Установить белый цвет шрифта
    qp.setPen(QColor(Qt::white));
    //Установить ранее созданный шрифт
    qp.setFont(font);

    //Переместить указатель на середину экрана
    qp.translate(QPoint(width/2, height/2));
    //Написать сообщение
    qp.drawText(-textWidth/2, 0, message);
}
