#include <QPainter>
#include <QRandomGenerator>
#include "drawermanager.h"

//Конструктор класса. Создает экземляр класса на основе базового класса QWidget и инициализирует игру
//Принимает ссылку на QWidget
//Не возвращает значений
DrawerManager::DrawerManager(QWidget *parent) : QWidget(parent) {
    //Установить цвет фона
    setStyleSheet(GameManager::getBACKGROUND_COLOUR());
    //Изменить размер окна
    resize(GameManager::getB_WIDTH(), GameManager::getB_HEIGHT());
    //Загрузить изображения
    loadImages();
    //Инициализировать начало игры
    initGame();
}

//Событие отрисовки
//Принимает ссылку на QPainterEvent
//Не возвращает значений
void DrawerManager::paintEvent(QPaintEvent *e) {
    //Убрать неиспользуемые предупреждения
    Q_UNUSED(e);
    //Начать отрисовку объектов
    doDrawing();
}

//Событие таймера. Срабатывает каждый кадр, количетсво вызовов зависит от задержки, указанной в GameManager.h
//Принимает ссылку на QTimerEvent
//Не возвращает значений
void DrawerManager::timerEvent(QTimerEvent *e) {
    //Убрать неиспользуемые предупреждения
    Q_UNUSED(e);

    //Если игра все еще идет
    if (inGame) {
        //Проверить, не съела ли змейка яблоко
        checkApple();
        //Проверить, не врезалась ли змейка в стену или в себя
        checkCollision();
        //Переместить змейку внутри окна
        move();
    }

    //отрисовать экран заново
    repaint();
}

//Событие нажатия кнопки. Срабатывает при нажатии кнопки
//Принимает ссылку на QKeyEvent
//Не возвращает значений
void DrawerManager::keyPressEvent(QKeyEvent *e) {

    //Получить ключ нажатой кнопки
    int key = e->key();

    //Если нажат пробел и игра закончена
    if(InputManager::getInstance()->changeDirection(key) && !inGame)
    {
        //то начать игру заново
        initGame();
    }

    //Вызвать событие нажатия кнопки в    QWidget
    QWidget::keyPressEvent(e);
}

//Функция загрузки изображений из ресурсов
//Не принимает значений
//Не возвращает значений
void DrawerManager::loadImages() {
    //Подгрузить изображения из указанных в GameManager.h путей
    dot.load(GameManager::getDOT_PATH());
    head.load(GameManager::getHEAD_PATH());
    apple.load(GameManager::getAPPLE_PATH());
}
//Функция старта игры
//Не принимает значений
//Не возвращает значений
void DrawerManager::initGame() {

    //Сделать игру активной
    inGame = true;
    //Обнулить направление движения змейки
    InputManager::getInstance()->dropDirection();

    //Сделать количество точек у игрока начальным
    dots = GameManager::getSTART_DOTS();

    //Установить начальные позиции змейки
    for (int z = 0; z < dots; z++) {
        if (z==0)
        {
            Head::getInstance()->setHead(GameManager::getSTART_POS(),GameManager::getSTART_POS());
        }
        points[z].setPos(GameManager::getSTART_POS() - z * 10, GameManager::getSTART_POS());
    }

    //переместить яблоко
    locateApple();

    //Создать таймер
    timerId = startTimer(GameManager::getDELAY());
}

//Функция перемещения яблока
//Не принимает значений
//Не возвращает значений
void DrawerManager::locateApple() {

    //Сгенерировать случайные координаты x и y
    int rx =  QRandomGenerator::global()->generate() % GameManager::getRAND_POS() * GameManager::getDOT_SIZE();
    int ry = QRandomGenerator::global()->generate() % GameManager::getRAND_POS() * GameManager::getDOT_SIZE();
    //Переместить яблоко на случайные координаты
    Apple::getInstance()->relocate(rx,ry);
}

//Функция проверки столкновения змейки с яблоком
//Не принимает значений
//Не возвращает значений
void DrawerManager::checkApple() {

    //Если координаты головы и яблока совпадают
    if (((Head::getInstance()->getX()) == Apple::getInstance()->getX()) && (Head::getInstance()->getY()) == Apple::getInstance()->getY()) {
        //то добавить змейке точку
        dots++;
        //и переместить яблоко
        locateApple();
    }

    //Если количество точек змейки больше или равно максимальному
    if (dots >= ALL_DOTS)
    {
        //то завершить игру
        inGame = false;
    }
}

//Функция проверки столкновения змейки со стеной или собой
//Не принимает значений
//Не возвращает значений
void DrawerManager::checkCollision() {

    //Проверить каждую точку змейки
    for (int z = dots; z > 0; z--) {

        //Если координаты головы и точки совпадают
        if ((z > GameManager::getSTART_DOTS() + 1) && (Head::getInstance()->getX() == points[z].getX()) && (Head::getInstance()->getY() == points[z].getY())) {
            //то закончить игру
            inGame = false;
        }
    }

    //Если координаты головы вышли за рамки экрана
    if (Head::getInstance()->getY() >= GameManager::getB_HEIGHT() ||
            Head::getInstance()->getY() < 0 ||
            Head::getInstance()->getX() >= GameManager::getB_WIDTH()||
            Head::getInstance()->getX() < 0) {
        //то закончить игру
        inGame = false;
    }

    //Если игра закончена
    if(!inGame) {
        //то уничтожить таймер
        killTimer(timerId);
    }
}

//Функция перемещения змейки
void DrawerManager::move() {
    //Создать значения для смещения змейки
    int offsetX = 0;
    int offsetY = 0;
    //Переместить каждую точку на координату следующей точки
    for (int z = dots; z > 0; z--) {
        if(z == 1)
        {
            points[z].setPos(Head::getInstance()->getX(),Head::getInstance()->getY());
        }
        else
        {
            points[z].setPos(points[(z-1)].getX(), points[(z-1)].getY());
        }

    }

    //Если текущее направление - влево
    if (InputManager::getInstance()->getLeftDirection()) {
        //то добавить смещение влево
        offsetX += GameManager::getDOT_SIZE();
    }
    //Если текущее направление - вправо
    if (InputManager::getInstance()->getRightDirection()) {
        //то добавить смещение вправо
        offsetX -= GameManager::getDOT_SIZE();
    }
    //Если текущее направление - вверх
    if (InputManager::getInstance()->getUpDirection()) {
        //то добавить смещение вверх
        offsetY += GameManager::getDOT_SIZE();
    }
    //Если текущее направление - вниз
    if (InputManager::getInstance()->getDownDirection()) {
        //то добавить смещение вниз
        offsetY -= GameManager::getDOT_SIZE();
    }

    //Переместить голову на указанное смещение
    Head::getInstance()->moveHead(offsetX,offsetY);
}

//Функция отрисовки змейки и яблока
//Не принимает значений
//Не возвращает значений
void DrawerManager::doDrawing() {

    //Создать объект QPainter
    QPainter qp(this);

    //Если игра все еще идет
    if (inGame) {
        //то отрисовать яблоко
        qp.drawImage(Apple::getInstance()->getX(), Apple::getInstance()->getY(), apple);

        //и голову с точками
        for (int z = 0; z < dots; z++) {
            if (z == 0) {
                qp.drawImage(Head::getInstance()->getX(), Head::getInstance()->getY(), head);
            } else {
                qp.drawImage(points[z].getX(), points[z].getY(), dot);
            }
        }
    //иначе
    } else {
        //вывести экран конца игры
        GameOverScreen::getInstance()->gameOver(qp, height(), width(),(dots - GameManager::getSTART_DOTS()));
    }
}




