#include "singleton.h"

//Обнуляем ссылку на экземляр класса во избежание ошибок
Singleton* Singleton::p_instance = 0;
