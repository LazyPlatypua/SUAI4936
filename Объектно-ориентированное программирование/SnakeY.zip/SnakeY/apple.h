#ifndef APPLE_H
#define APPLE_H

#include "item.h"

//Класс яблока. Отвечает за его расположение и релокацию
class Apple : public Item
{
public:
    //Станадартный пустой конструктор
    Apple() {};
    //Переместить яблоко в указанные координаты
    void relocate(int,int);
    //Получить ссылку на экземпляр яблока
    static Apple * getInstance() {
        if(!my_instance)
            my_instance = new Apple();
        return my_instance;
    }

private:
    //Ссылка на единственный экземляр яблока
    static Apple * my_instance;
};

#endif // APPLE_H
