package com.example.lab2spring.exception;

public class ElectronicAlreadyExistException extends Exception {
    public ElectronicAlreadyExistException(String message) {
        super(message);
    }
}
