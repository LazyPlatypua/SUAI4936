package com.example.lab2spring.exception;

public class ElectronicAreEmptyException extends Exception {
    public ElectronicAreEmptyException (String message) {
        super(message);
    }
}
