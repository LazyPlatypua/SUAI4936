#ifndef GAMEOVERSCREEN_H
#define GAMEOVERSCREEN_H
#include "QPainter"
#include "singleton.h"

//Класс экрана конца игры. Отвечает за отрисовку экрана со счетом
class GameOverScreen : public Singleton
{
public:
    //Стандартный пустой конструктор
    GameOverScreen(){}
    //Функция отрисовки экрана конца игры
    void gameOver(QPainter&, int, int, int);
    //Получить ссылку на экземпляр экрана
    static GameOverScreen * getInstance() {
        if(!my_instance)
            my_instance = new GameOverScreen();
        return my_instance;
    }

private:
    //Ссылка на единственный экземляр экрана
    static GameOverScreen * my_instance;
};
#endif // GAMEOVERSCREEN_H
