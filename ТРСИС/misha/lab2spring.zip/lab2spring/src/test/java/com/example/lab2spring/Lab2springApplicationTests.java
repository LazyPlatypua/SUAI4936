package com.example.lab2spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2springApplicationTests {

	@Test
	void contextLoads() {

	}

}
