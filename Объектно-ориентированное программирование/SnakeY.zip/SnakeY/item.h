#ifndef ITEM_H
#define ITEM_H
#include "coords.h"
#include "singleton.h"

//Класс предмета. Отвечает за координаты предмета и то, что он находится в единственном экземпляре
class Item : public Singleton, public Coords
{
public:
    //стандартный пустой конструктор
    Item(){}
};

#endif // ITEM_H
