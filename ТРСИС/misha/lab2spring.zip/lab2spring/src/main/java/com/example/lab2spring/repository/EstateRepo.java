package com.example.lab2spring.repository;

import com.example.lab2spring.entity.Estate;
import org.springframework.data.repository.CrudRepository;


public interface EstateRepo extends CrudRepository<Estate, Long> {
    Estate findEstateByName(String name);
}
