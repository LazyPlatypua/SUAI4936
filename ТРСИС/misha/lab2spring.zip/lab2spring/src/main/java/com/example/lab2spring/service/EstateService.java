package com.example.lab2spring.service;

import com.example.lab2spring.entity.Estate;
import com.example.lab2spring.entity.User;
import com.example.lab2spring.exception.ElectronicAreEmptyException;
import com.example.lab2spring.exception.ElectronicNotFoundException;
import com.example.lab2spring.repository.EstateRepo;
import com.example.lab2spring.repository.UserDetailsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstateService {

    @Autowired
    private EstateRepo estateRepo;

    @Autowired
    private UserDetailsRepo userRepo;

    public void addEstate(Estate estate) throws Exception {
        if (estate.getName() == null || estate.getAddress() == null || estate.getCost() == null)
            throw new ElectronicAreEmptyException("Данные не могут иметь пустых значений");

        estateRepo.save(estate);
    }

    public Optional<Estate> getEstate(Long id) throws ElectronicNotFoundException {
        var estate = estateRepo.findById(id);
        if (estate.isEmpty()) {
            throw new ElectronicNotFoundException("Недвижимость не была найдена");
        }
        return estate;
    }

    public List<Estate> getEstates() {
        List<Estate> estates = (List<Estate>) estateRepo.findAll();
        return estates;
    }



    public Long deleteEstate(Long id) throws  ElectronicNotFoundException {
        estateRepo.deleteById(id);
        return id;
    }


}