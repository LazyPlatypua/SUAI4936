#include "coords.h"

//Получить x
//Не принимает значений
//Возвращает значение int
int Coords::getX() const
{
    return x;
}

//Установить x
//Принимает значение int
//Не возвращает значений
void Coords::setX(int value)
{
    x = value;
}

//Получить y
//Не принимает значений
//Возвращает значение int
int Coords::getY() const
{
    return y;
}

//Установить y
//Принимает значение int
//Не возвращает значений
void Coords::setY(int value)
{
    y = value;
}
