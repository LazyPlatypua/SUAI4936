#include "inputmanager.h"

//Обнуляем ссылку на экземляр класса во избежание ошибок
InputManager* InputManager::my_instance = 0;

//Изменить направление в зависимости от передаваемого ключа кнопки. Возвращает true, если нажат Пробел (Space) и false в ином случае
//Принимает значение int
//Возвращает значение bool
bool InputManager::changeDirection(int key) {
    //Если нажата клавша влево и не выбрано направление вправо
    if ((key == Qt::Key_Left) && (!rightDirection)) {
        //Сделать текущим направлением "влево"
        leftDirection = true;
        upDirection = false;
        downDirection = false;
    }
    //Если нажата клавша вправо и не выбрано направление влево
    if ((key == Qt::Key_Right) && (!leftDirection)) {
        //Сделать текущим направлением "вправо"
        rightDirection = true;
        upDirection = false;
        downDirection = false;
    }
    //Если нажата клавша вверх и не выбрано направление вниз
    if ((key == Qt::Key_Up) && (!downDirection)) {
        //Сделать текущим направлением "вверх"
        upDirection = true;
        rightDirection = false;
        leftDirection = false;
    }
    //Если нажата клавша вниз и не выбрано направление вверх
    if ((key == Qt::Key_Down) && (!upDirection)) {
        //Сделать текущим направлением "вниз"
        downDirection = true;
        rightDirection = false;
        leftDirection = false;
    }

    //Возвращает true, если нажат Пробел (Space) и false в ином случае
    if(key == Qt::Key_Any)
    {
        return true;
    }
    else
    {
        return false;
    }
}
//Отчистить направление движения
//Не принимает значений
//Не возвращает значений
void InputManager::dropDirection()
{
    leftDirection = false;
    rightDirection = true;
    upDirection = false;
    downDirection = false;

}
//Получить значение левого направления
//Не принимает значений
//Возвращает значение bool
bool InputManager::getLeftDirection() const
{
    return leftDirection;
}

//Получить значение правого направления
//Не принимает значений
//Возвращает значение bool
bool InputManager::getRightDirection() const
{
    return rightDirection;
}

//Получить значение верхнего направления
//Не принимает значений
//Возвращает значение bool
bool InputManager::getUpDirection() const
{
    return upDirection;
}

//Получить значение нижнего направления
//Не принимает значений
//Возвращает значение bool
bool InputManager::getDownDirection() const
{
    return downDirection;
}
