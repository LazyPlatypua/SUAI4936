#ifndef HEAD_H
#define HEAD_H

#include "item.h"

//Класс головы змеи. Отвечает за расположение активного участка змеи
class Head : public Item
{
public:
    //Стандартный пустой конструктор
    Head(){}
    //Установить положение головы на указанные координаты x и y
    void setHead(int,int);
    //Сместить положение головы на указанные значения
    void moveHead(int,int);
    //Получить ссылку на экземпляр головы
    static Head * getInstance() {
        if(!my_instance)
            my_instance = new Head();
        return my_instance;
    }

private:
    //Ссылка на единственный экземляр головы
    static Head * my_instance;
};

#endif // HEAD_H
