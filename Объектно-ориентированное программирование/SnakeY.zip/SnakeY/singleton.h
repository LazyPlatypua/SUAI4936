#ifndef SINGLETON_H
#define SINGLETON_H

//Базовый класс. Отвечает за создание и поддержание единтсвенного экземляра класса
class Singleton
{
public:
    //Получить ссылку на единственный экземляр класса
    static Singleton * getInstance() {
        if(!p_instance)
            p_instance = new Singleton();
        return p_instance;
    }
protected:
    //Статичная ссылка на экземпляр класса
    static Singleton * p_instance;
    //Стандартный пустой конструктор
    Singleton() {}
    //Конструктор с параметром
    Singleton( const Singleton& );
    //Переопределение оператора =
    Singleton& operator=( Singleton& );
};
#endif // SINGLETON_H
