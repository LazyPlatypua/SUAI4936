#ifndef INPUTMANAGER_H
#define INPUTMANAGER_H
#include <QKeyEvent>
#include "singleton.h"
#include "QWidget"

//Класс менеджера ввода. Отвечает за направление движения змеи
class InputManager : public Singleton
{
public:
    //Стандартный пустой конструктор
    InputManager(){}
    //Изменить направление в зависимости от передаваемого ключа кнопки
    bool changeDirection(int);
    //Отчистить направление движения
    void dropDirection();
    //Получить значение левого направления
    bool getLeftDirection() const;
    //Получить значение правого направления
    bool getRightDirection() const;
    //Получить значение верхнего направления
    bool getUpDirection() const;
    //Получить значение нижнего направления
    bool getDownDirection() const;
    //Получить ссылку на экземпляр головы
    static InputManager * getInstance() {
        if(!my_instance)
            my_instance = new InputManager();
        return my_instance;
    }

private:
    //Движется ли змейка налево?
    bool leftDirection;
    //Движется ли змейка направо?
    bool rightDirection;
    //Движется ли змейка вверх?
    bool upDirection;
    //Движется ли змейка вниз?
    bool downDirection;
    //Ссылка на единственный экземляр менеджера ввода
    static InputManager * my_instance;
};

#endif // INPUTMANAGER_H
