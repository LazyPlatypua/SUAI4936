#include "gamemanager.h"

//Функция получения ширины окна
//Не принимает значений
//Возвращает значение int
int GameManager::getB_WIDTH()
{
    return B_WIDTH;
}

//Функция получения высоты окна
//Не принимает значений
//Возвращает значение int
int GameManager::getB_HEIGHT()
{
    return B_HEIGHT;
}

//Функция получения размера точек
//Не принимает значений
//Возвращает значение int
int GameManager::getDOT_SIZE()
{
    return DOT_SIZE;
}

//Функция получения ограничения случайной генерации
//Не принимает значений
//Возвращает значение int
int GameManager::getRAND_POS()
{
    return RAND_POS;
}

//Функция получения задержки между кадрами
//Не принимает значений
//Возвращает значение int
int GameManager::getDELAY()
{
    return DELAY;
}

//Функция получения начального количества точек у змейки
//Не принимает значений
//Возвращает значение int
int GameManager::getSTART_DOTS()
{
    return START_DOTS;
}

//Функция получения начального расположения змейки
//Не принимает значений
//Возвращает значение int
int GameManager::getSTART_POS()
{
    return START_POS;
}

//Функция получения пути до изображения точки (тела змеи)
//Не принимает значений
//Возвращает значение char*
const char *GameManager::getDOT_PATH()
{
    return DOT_PATH;
}

//Функция получения пути до изображения головы
//Не принимает значений
//Возвращает значение char*
const char *GameManager::getHEAD_PATH()
{
    return HEAD_PATH;
}

//Функция получения пути до изображения яблока
//Не принимает значений
//Возвращает значение char*
const char *GameManager::getAPPLE_PATH()
{
    return APPLE_PATH;
}

//Функция получения цвета фона
//Не принимает значений
//Возвращает значение char*
const char *GameManager::getBACKGROUND_COLOUR()
{
    return BACKGROUND_COLOUR;
}

