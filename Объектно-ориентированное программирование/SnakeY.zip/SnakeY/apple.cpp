#include "apple.h"

//Обнуляем ссылку на экземляр класса во избежание ошибок
Apple* Apple::my_instance = 0;

//Переместить яблоко в указанные координаты
//Принимает значения int
//Не возвращает значений
void Apple::relocate(int newx, int newy)
{
    setX(newx);
    setY(newy);
}
