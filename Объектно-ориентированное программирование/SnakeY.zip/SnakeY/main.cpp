#include <QApplication>
#include "drawermanager.h"

//Класс main - запуск приложения
int main(int argc, char *argv[]) {

    //Создать экземляр приложения
    QApplication app(argc, argv);

    //Создать экземляр DrawerManager
    DrawerManager window;

    //Установить название окна приложения
    window.setWindowTitle("Snake");
    //Показать окно приложения
    window.show();

    //Вернуть выполняемое приложение
    return app.exec();
}
